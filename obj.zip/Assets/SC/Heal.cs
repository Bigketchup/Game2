﻿using UnityEngine;
using System.Collections;

public class Heal : MonoBehaviour {
    public GameObject player;

    void OnTriggerEnter(Collider player)
    {
        if (player.tag == "Player")
        {
            Helath.health += 20;
            Destroy(gameObject);
        }
    }

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        gameObject.transform.Rotate(0, 1, 0);
	}
}
