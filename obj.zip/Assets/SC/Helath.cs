﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Helath : MonoBehaviour {
    public static int health = 100;
    public GameObject player;
    public Slider healthBar;
	void Start ()
    {
        InvokeRepeating("ReduceHealth", 1, 1);
	}
	
    void ReduceHealth ()
    {
        print("HP : " +health);
        healthBar.value = health;
        if (health <= 0)
        {
            print("You Died");
        }
    }
	
	void Update ()
    {
	
	}
}
