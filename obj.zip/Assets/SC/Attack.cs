﻿using UnityEngine;
using System.Collections;

public class Attack : MonoBehaviour
{
    public GameObject player;

    void OnTriggerEnter(Collider player)
	{
		if (player.tag == "Player") {
			Helath.health -= 20;
		}
	}

	// Use this for initialization
	void Start ()
    {
	
	}
	
	// Update is called once per frame
	void Update ()
    {
	
	}
}
