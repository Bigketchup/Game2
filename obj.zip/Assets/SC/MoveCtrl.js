﻿#pragma strict
public var Speed = 15;
public var BackSpeed =11;

function Update () {

    if(Input.GetKey(KeyCode.W))
    {
        transform.Translate(Vector3.forward * Speed * Time.deltaTime);
    }
    if(Input.GetKey(KeyCode.S))
    {
        transform.Translate(-Vector3.forward * BackSpeed * Time.deltaTime);
    }
    if(Input.GetKey(KeyCode.A))
    {
        transform.Translate(Vector3.left * Speed * Time.deltaTime);
    }
    if(Input.GetKey(KeyCode.D))
    {
        transform.Translate(-Vector3.left * Speed * Time.deltaTime);
    }
}