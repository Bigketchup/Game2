﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class MotherShip : MonoBehaviour {
    private Animator anim;

	// Use this for initialization
	void Awake() {
        anim = GameObject.Find("Canvas").GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
	if (Helath.health <= 0)
        {
            anim.SetTrigger("IsGameOver");
            if (Input.GetKey(KeyCode.Y))
            {
				Helath.health = 100;
				SceneManager.LoadScene ("as");
            }
        }
	}
}
