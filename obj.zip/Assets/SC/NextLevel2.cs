﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class NextLevel2: MonoBehaviour {


    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            Application.LoadLevel("as3");
            //SceneManager.LoadScene("as3");
        }
    }

	// Update is called once per frame
	void Update () {
		transform.Rotate (new Vector3 (15, 30, 45) * Time.deltaTime);
	}
}
