﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class NextLevel1: MonoBehaviour {

	public GameObject player;

    void OnTriggerEnter(Collider player)
    {
        if (player.tag == "Player")
        {
            SceneManager.LoadScene("as2");
        }
    }
	
	// Update is called once per frame
	void Update () {
        transform.Rotate(new Vector3(15, 30, 45) * Time.deltaTime);
    }
}
